
package org.foobar;

public class Foobar
{
  public String getName()
  {
    return "foobar";
  }
}
