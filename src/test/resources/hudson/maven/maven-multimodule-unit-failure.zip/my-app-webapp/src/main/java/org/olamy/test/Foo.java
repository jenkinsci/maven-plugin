package org.olamy.test;

public class Foo
{

}
