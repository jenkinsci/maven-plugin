package test;

/**
 * Hello world!
 *
 */
public class AppAA 
{
    public static void main( String[] args )
    {
        System.out.println( "Goodbye World!" );
    }
}
